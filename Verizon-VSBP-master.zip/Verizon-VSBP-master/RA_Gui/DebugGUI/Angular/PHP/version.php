<?php
$output = shell_exec('cat /opt/common/VERSION ');
echo "<pre>$output</pre>";
$output = vdata;
echo json_encode($output,JSON_FORCE_OBJECT);
?>
