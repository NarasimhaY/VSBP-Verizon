/*logout controller*/
app.controller('logoutController'[function (da




}]);


